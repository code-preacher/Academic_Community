<?php
include_once "config.php";

class Crud extends Config
{

	function __construct()
	{
		parent::__construct();
	}


//Display All
	public function displayAll($table)
	{
		$query = "SELECT * FROM {$table}";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}


		public function displayAllSpecific($table,$item,$value)
	{
		$query = "SELECT * FROM {$table} WHERE $item='$value'";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}

	public function displayAllSpecificWithOrder($table,$item,$value,$orderValue,$orderType)
	{
		$query = "SELECT * FROM {$table} WHERE $item='$value' ORDER BY $orderValue $orderType";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}



	public function displayAllWithOr($user_id)
	{
		$query = "SELECT * FROM chat where sender='$user_id' or reciever='$user_id ' order by id desc";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}



		public function displayAllWithOr2($user_id,$doc_id)
	{
		$query = "SELECT * FROM chat where (sender='$user_id' AND reciever='$doc_id ') OR (sender='$doc_id' AND reciever='$user_id ') order by id desc";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}


	//Display with Order


	public function displayAllWithOrder($table,$orderValue,$orderType)
	{
		$query = "SELECT * FROM {$table} ORDER BY {$orderValue} {$orderType}";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}


	public function displayAllWithOrder2($table,$user,$orderValue,$orderType)
	{
		$query = "SELECT * FROM {$table} WHERE user_id='$user' ORDER BY {$orderValue} {$orderType}";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}



		public function displayAllWithOrder3($table,$user,$orderValue,$orderType)
	{
		$query = "SELECT * FROM {$table} WHERE user_id='$user' ORDER BY {$orderValue} {$orderType}";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}



	public function displayUser2($v1,$v2)
	{
		
		$query = "SELECT * FROM user where id='$v1' or id='$v2' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		}else{
			return 0;
		}
	}





	//Display with Limit
	public function displayWithLimit($table,$limit)
	{
		$query = "SELECT * FROM {table} limit {$limit}";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$data = array();
			while ($row = $result->fetch_assoc()) {
				$data[] = $row;
			}
			return $data;
		}else{
			return 0;
		}
	}


	//Display Specific
	public function displayOne($table,$value)
	{
		$id = $this->cleanse($value);
		$query = "SELECT * FROM $table where id='$id' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		}else{
			return 0;
		}
	}


	public function displayUser($value)
	{
		$id = $this->cleanse($value);
		$query = "SELECT * FROM user where email='$id' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		}else{
			return 0;
		}
	}


	public function displayUser3($table,$value)
	{
		$id = $this->cleanse($value);
		$query = "SELECT * FROM {$table} where email='$id' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		}else{
			return 0;
		}
	}




	public function displayLoginUser($value)
	{
		$id = $this->cleanse($value);
		$query = "SELECT * FROM login where email='$id' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		}else{
			return 0;
		}
	}

	public function displayIdByEMail($table,$email)
	{
		$query = "SELECT id FROM {$table} where email='$email' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row['id'];
		}else{
			return 0;
		}
	}


		public function displayDeptIdByEMail($table,$email)
	{
		$query = "SELECT department_id FROM {$table} where email='$email' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row['department_id'];
		}else{
			return 0;
		}
	}




public function displayEmailById($table,$id)
	{
		$query = "SELECT email FROM {$table} where id='$id' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row['email'];
		}else{
			return 0;
		}
	}


		public function displayChargeById($table,$value)
	{
		$id = $this->cleanse($value);
		$query = "SELECT * FROM {$table} where id='$id' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row['charge'];
		}else{
			return 0;
		}
	}


	public function displayNameById($table,$value)
	{
		$id = $this->cleanse($value);
		$query = "SELECT * FROM {$table} where id='$id' ";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row['name'];
		}else{
			return 0;
		}
	}



	
//Counting All
	public function countAll($table)
	{
		$q=$this->con->query("SELECT id FROM $table");
		return $q->num_rows;
	}


	public function countAllById($table,$id)
	{
		$q=$this->con->query("SELECT id FROM $table where sender='$id' or reciever='$id' ");
		return $q->num_rows;
	}

	public function countAllById2($table,$id)
	{
		$q=$this->con->query("SELECT id FROM $table where (sender='$id' or reciever='$id') AND status='0' ");
		return $q->num_rows;
	}

	public function countAllById20($table,$id)
	{
		$q=$this->con->query("SELECT id FROM $table where (sender='$id' or reciever='$id') AND status2='0' ");
		return $q->num_rows;
	}

	public function countAllById22($table,$id)
	{
		$q=$this->con->query("SELECT id FROM $table where (sender='$id' or reciever='$id') AND status2='0' ");
		return $q->num_rows;
	}

	public function countAllById3($table,$item,$value)
	{
		$q=$this->con->query("SELECT id FROM $table where $item='$value'");
		return $q->num_rows;
	}


	public function countAllById4($table,$item,$value,$item2,$value2)
	{
		$q=$this->con->query("SELECT id FROM $table where $item='$value' AND $item2='$value2'");
		return $q->num_rows;
	}

	public function countAllById5($user_id,$doc_id)
	{
		$q = $this->con->query("SELECT id FROM chat where (sender='$user_id' AND reciever='$doc_id ' AND status='0') OR (sender='$doc_id' AND reciever='$user_id' AND status='0')");
		return $q->num_rows;
	}

	public function countAllById50($user_id,$doc_id)
	{
		$q = $this->con->query("SELECT id FROM chat where (sender='$user_id' AND reciever='$doc_id ' AND status2='0') OR (sender='$doc_id' AND reciever='$user_id' AND status2='0')");
		return $q->num_rows;
	}


	public function countAllById6($user_id,$doc_id)
	{
		$q = $this->con->query("SELECT id FROM chat where (sender='$user_id' AND reciever='$doc_id ' AND status2='0') OR (sender='$doc_id' AND reciever='$user_id' AND status2='0')");
		return $q->num_rows;
	}

	public function countAllById66($user_id,$doc_id)
	{
		$q = $this->con->query("SELECT id FROM chat where (sender='$user_id' AND reciever='$doc_id ') OR (sender='$doc_id' AND reciever='$user_id')");
		return $q->num_rows;
	}



	public function countAllComplain($table,$id)
	{
		$q=$this->con->query("SELECT sender FROM $table where sender='$id' ");
		return $q->num_rows;
	}



//Counting Specific
	
	
// Inserting

	public function insertChat($post)
	{
		$msg = $this->cleanse($_POST['message']);
		$id= $this->cleanse($_POST['id']);
		$lecturer_id= $this->cleanse($_POST['lecturer_id']);
		$id2= $this->cleanse($_POST['id2']);

		$query="INSERT INTO chat(user_type,sender,reciever,message) VALUES('lecturer','$lecturer_id','$id','$msg')";
		$sql = $this->con->query($query);
		if ($sql==true) {
			header("Location:reply.php?id=$id2&msg=Data was successfully inserted&type=success");
		}else{
			header("Location:reply.php?id=$id2&msg=Error adding data try again!&type=error");
		}
	}



		public function insertChat2($post)
	{
		$msg = $this->cleanse($_POST['message']);
		$id= $this->cleanse($_POST['id']);
		$user_id= $this->cleanse($_POST['user_id']);
		$id2= $this->cleanse($_POST['id2']);

		$query="INSERT INTO chat(user_type,sender,reciever,message) VALUES('student','$user_id','$id','$msg')";
		$sql = $this->con->query($query);
		if ($sql==true) {
			header("Location:reply2.php?id=$id2&msg=Data was successfully inserted&type=success");
		}else{
			header("Location:reply2.php?id=$id2&msg=Error adding data try again!&type=error");
		}
	}


	public function insertChat3($post)
	{
		$msg = $this->cleanse($_POST['message']);
		$id= $this->cleanse($_POST['id']);
		$user_id= $this->cleanse($_POST['user_id']);
		$id2= $this->cleanse($_POST['id2']);

		$query="INSERT INTO chat(user_type,sender,reciever,message) VALUES('marketers','$user_id','$id','$msg')";
		$sql = $this->con->query($query);
		if ($sql==true) {
			header("Location:reply3.php?id=$id2&msg=Data was successfully inserted&type=success");
		}else{
			header("Location:reply3.php?id=$id2&msg=Error adding data try again!&type=error");
		}
	}




		public function addLecturer($post)
	{

		$name = $this->cleanse($_POST['name']);
		$email = $this->cleanse($_POST['email']);
		$phone = $this->cleanse($_POST['phone']);
		$address = $this->cleanse($_POST['address']);
		$password = $this->cleanse($_POST['password']);
		$gender = strtolower($this->cleanse($_POST['gender']));
		$department_id = $this->cleanse($_POST['department_id']);
		$role='2';

		$query="INSERT INTO lecturer(name,email,phone,address,password,gender,department_id) VALUES('$name','$email','$phone','$address','$password','$gender','$department_id')";
		$query2="INSERT INTO login(name,email,password,role) VALUES('$name','$email','$password','$role')";
		$sql = $this->con->query($query);
		if ($sql==true) {
			$this->con->query($query2);
			header("Location:view-lecturer.php?msg=Lecturer was created successfully&type=success");
		}else{
			header("Location:view-lecturer.php?msg=Error adding data try again!&type=error");
		}
	}


	public function addStudent($post)
	{

		$name = $this->cleanse($_POST['name']);
		$email = $this->cleanse($_POST['email']);
		$phone = $this->cleanse($_POST['phone']);
		$address = $this->cleanse($_POST['address']);
		$password = $this->cleanse($_POST['password']);
		$gender = strtolower($this->cleanse($_POST['gender']));
		$department_id = $this->cleanse($_POST['department_id']);
		$role='3';

		$query="INSERT INTO student(name,email,phone,address,password,gender,department_id) VALUES('$name','$email','$phone','$address','$password','$gender','$department_id')";
		$query2="INSERT INTO login(name,email,password,role) VALUES('$name','$email','$password','$role')";
		$sql = $this->con->query($query);
		if ($sql==true) {
			$this->con->query($query2);
			header("Location:view-student.php?msg=Student was created successfully&type=success");
		}else{
			header("Location:view-student.php?msg=Error adding data try again!&type=error");
		}
	}


	public function addMarketers($post)
	{

		$name = $this->cleanse($_POST['name']);
		$email = $this->cleanse($_POST['email']);
		$phone = $this->cleanse($_POST['phone']);
		$address = $this->cleanse($_POST['address']);
		$password = $this->cleanse($_POST['password']);
		$gender = strtolower($this->cleanse($_POST['gender']));
		$product = $this->cleanse($_POST['product']);
		$role='4';

		$query="INSERT INTO marketers(name,email,phone,address,password,gender,product) VALUES('$name','$email','$phone','$address','$password','$gender','$product')";
		$query2="INSERT INTO login(name,email,password,role) VALUES('$name','$email','$password','$role')";
		$sql = $this->con->query($query);
		if ($sql==true) {
			$this->con->query($query2);
			header("Location:view-marketers.php?msg=Marketers was created successfully&type=success");
		}else{
			header("Location:view-marketers.php?msg=Error adding data try again!&type=error");
		}
	}






	public function addDepartment($post)
	{
		$name = strtoupper($this->cleanse($_POST['name']));

		$query="INSERT INTO department(name) VALUES('$name')";
		$sql = $this->con->query($query);
		if ($sql==true) {
			header("Location:view-department.php?msg=Department was created successfully&type=success");
		}else{
			header("Location:view-department.php?msg=Error adding data try again!&type=error");
		}
	}





//Delete Items
	public function delete($id, $table,$url) 
	{ 
		$id = $this->cleanse($id);
		$query = "DELETE FROM $table WHERE id = $id";

		$result = $this->con->query($query);

		if ($result == true) {
			header("Location:$url?msg=Data was successfully deleted&type=success");
		} else {
			header("Location:$url?msg=Error deleting data&type=error");
		}
	}


	public function deleteAll($id, $table,$url) 
	{ 
		$email= $this->cleanse($id);
		$query = "DELETE FROM $table WHERE email = '$email' ";
		$query2 = "DELETE FROM login WHERE email = '$email' ";

		$result = $this->con->query($query);

		if ($result == true) {
			$this->con->query($query2);
			header("Location:$url?msg=Data was successfully deleted&type=success");
		} else {
			header("Location:$url?msg=Error deleting data&type=error");
		}
	}





	//Delete Items
	public function deleteTwoTable($email,$table,$table2,$url) 
	{ 
		$email = $this->cleanse($email);
		$query = "DELETE FROM {$table} WHERE email= '$email'";
		$query2 = "DELETE FROM {$table2} WHERE email= '$email'";

		$result = $this->con->query($query);

		if ($result == true) {
			header("Location:$url?msg=Data was successfully deleted&type=success");
			$this->con->query($query2);
		} else {
			header("Location:$url?msg=Error deleting Data&type=error");
		}
	}


	public function deleteThreeTable($email,$table,$table2,$url) 
	{ 
		$email = $this->cleanse($email);
		$query = "DELETE FROM {$table} WHERE email= '$email'";
		$query2 = "DELETE FROM {$table2} WHERE email= '$email'";

		$result = $this->con->query($query);

		if ($result == true) {
			header("Location:$url?msg=Data was successfully deleted&type=success");
			$this->con->query($query2);
		} else {
			header("Location:$url?msg=Error deleting Data&type=error");
		}
	}


	public function updateAdmin($post)
	{
		
		$email=$this->cleanse($_POST['email']);
		$password=$this->cleanse($_POST['password']);
		$query="UPDATE login SET password='$password' WHERE email='$email' ";
		$sql=$this->con->query($query);
		if ($sql==true) {
			header("Location:profile.php?msg=Account was updated successfully&type=success");
		}else{
			header("Location:profile.php?msg=Error updating account try again!&type=error");
		}
	}


	public function updateUser($post)
	{
		
		$email=$this->cleanse($_POST['email']);
		$password=$this->cleanse($_POST['password']);
		$query="UPDATE login SET password='$password' WHERE email='$email' ";
		$query2="UPDATE user SET password='$password' WHERE email='$email' ";
		$sql=$this->con->query($query);
		if ($sql==true) {
			$this->con->query($query2);
			header("Location:profile.php?msg=Account was updated successfully&type=success");
		}else{
			header("Location:profile.php?msg=Error updating account try again!&type=error");
		}
	}



	public function updateWasteInfoPay($value,$url)
	{
		$check=$this->displayOne('waste_info',$value);
		$pay=$check['payment_status'];
		if ($pay === '0') {
			$query="UPDATE waste_info SET payment_status='1' WHERE id='$value' ";
		} else {
			$query="UPDATE waste_info SET payment_status='0' WHERE id='$value' ";
		}

		$sql=$this->con->query($query);
		if ($sql==true) {
			header("Location:$url?msg=Payment was updated successfully&type=success");
		}else{
			header("Location:$url?msg=Error updating account try again!&type=error");
		}
	}
	

	public function updateWasteInfoDelivery($value,$url)
	{
		$check=$this->displayOne('waste_info',$value);
		
		$delivery=$check['delivery_status'];
		if ($delivery === '0') {
			$query="UPDATE waste_info SET delivery_status='1' WHERE id='$value' ";
		} else {
			$query="UPDATE waste_info SET delivery_status='0' WHERE id='$value' ";
		}

		$sql=$this->con->query($query);
		if ($sql==true) {
			header("Location:$url?msg=Delivery was updated successfully&type=success");
		}else{
			header("Location:$url?msg=Error updating account try again!&type=error");
		}
	}

	public function updateStatus($user_id,$doc_id)
	{
	$this->con->query("UPDATE chat SET status='1' WHERE (sender='$user_id' AND reciever='$doc_id ' AND status='0') OR (sender='$doc_id' AND reciever='$user_id' AND status='0') ");
	}

	public function updateStatus2($user_id,$doc_id)
	{
	$this->con->query("UPDATE chat SET status2='1' WHERE (sender='$user_id' AND reciever='$doc_id ' AND status2='0') OR (sender='$doc_id' AND reciever='$user_id' AND status2='0') ");
	}


	//Search
	public function displaySearch($value)
	{
	//Search box value assigning to $Name variable.
		$Name = $this->cleanse($value);
		$query = "SELECT * FROM product WHERE pid LIKE '%$Name%'";
		$result = $this->con->query($query);
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			return $row;
		}else{
			return false;
		}
	}


//Mailing Function
	public function mailing($post)
	{
		$name=$this->cleanse($_POST['name']);
		$email=$this->cleanse($_POST['email']);
		$phone=$this->cleanse($_POST['phone']);
		$subject=$this->cleanse($_POST['subject']);
		$text=$this->cleanse($_POST['message']);

		$headers = 'MIME-Version: 1.0' . "\r\n";
		$headers .= "From: " . $email . "\r\n"; // Sender's E-mail  ---charset=iso-8859-1
		$headers .= 'Content-type: text/html; charset=utf8_encode' . "\r\n";

		$message ='<table style="width:100%">
		<tr>
		<td>'.$name.'  '.$subject.'</td>
		</tr>
		<tr><td>Email: '.$email.'</td></tr>
		<tr><td>phone: '.$subject.'</td></tr>
		<tr><td>Text: '.$text.'</td></tr>

		</table>';
		$to='support@dilproperty.com';

		if (@mail($to, $subject, $message, $headers))
		{
			header("Location:contact.php?msg=Your message has been sent, we will contact you in a moment&type=success");
		}else{
			header("Location:contact.php?msg=message failed sending, please try again later!&type=error");
		}

	}



	public function cleanse($str)
	{
   #$Data = preg_replace('/[^A-Za-z0-9_-]/', '', $Data); /** Allow Letters/Numbers and _ and - Only */
		$str = htmlentities($str, ENT_QUOTES, 'UTF-8'); /** Add Html Protection */
		$str = stripslashes($str); /** Add Strip Slashes Protection */
		if($str!=''){
			$str=trim($str);
			return mysqli_real_escape_string($this->con,$str);
		}
	}


}

?>

