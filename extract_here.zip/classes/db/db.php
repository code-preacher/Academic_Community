<?php
define('DB_SERVER', 'localhost');
define('DB_NAME', 'community');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

?>

